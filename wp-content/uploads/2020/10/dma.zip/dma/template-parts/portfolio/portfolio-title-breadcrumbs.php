<div class="page-title normal-title portfolio-breadcrumb-title">
	<div class="page-title-inner container  flex-row medium-flex-wrap medium-text-center">
	 	<div class="flex-col flex-grow">
	 		<h1 class="entry-title is-larger uppercase pb-0 pt-0 mb-0"><?php the_title(); ?></h1>
	 	</div>
	 	<div class="flex-col flex-right">
			<?php get_flatsome_portfolio_breadcrumbs(); ?>
		</div>
	</div>
</div>