# NOTICE! DO NOT PLACE YOUR CUSTOM TRANSLATION FILES HERE!

Theme updates will delete/overwrite all custom translations placed in this directory.
Alternatively you can put translations in your child theme: `/wp-content/themes/your-child-theme/languages/en_US.po`.

# Please visit the following links to learn more about translating:

http://codex.wordpress.org/Translating_WordPress
https://docs.uxthemes.com/article/63-how-to-translate-the-theme
